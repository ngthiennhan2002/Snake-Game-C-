#include "Function.h"
using namespace std;
int rowMenu = 23;
int main()
{
	srand((int)time(NULL));
	system("cls");
	ResizeConsole(3000, 3000);
	FixConsoleWindow();
	noCursorType();
	ClearConsoleToColors(4, 14);
	loadPlayerName();


	int choose = NULL;
	chooseOptions(rowMenu, choose);
	return 0;
}