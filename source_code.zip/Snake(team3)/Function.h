#ifndef MYFUNCTION_H
#define MYFUNCTION_H
#include <iostream>
#include <thread>
#include <stdio.h>
#include <Windows.h>
#include <conio.h>
#include <ctime>
#include <string>
#include <fstream>
#pragma comment(lib, "winmm.lib")
using namespace std;

#define MAX_SIZE_SNAKE 24
#define UP		87
#define DOWN	83
#define LEFT	65
#define RIGHT	68


#define WALL_UP		5
#define WALL_DOWN	37
#define WALL_LEFT	5
#define WALL_RIGHT	120 

struct Point
{
	int x = NULL;
	int y = NULL;
};

struct Stat
{
	string name;
	int score = NULL;
	int speed = NULL;
};

struct load {
	string name;
	int score;
	int speed;
	int size;
	int foodRemain;
	int charLock;
	int direction;
	int speedCheck;
	int levelCheck;
	int pauseCheck;
	int language;
	POINT food;
	POINT snake[MAX_SIZE_SNAKE];
	char date[26];
};

void ResizeConsole(int width, int height);
void FixConsoleWindow();
void GotoXY(int x, int y);
void noCursorType();
void setFontSize(int FontSize);
void SetColor(int ForgC);
void ClearConsoleToColors(int ForgC, int BackC);
void CreateMenuList(int& rowMenu);
void chooseOptions(int& rowMenu, int& choose);
void DrawWord();
void DrawWordS();
void DrawWordN();
void DrawWordA();
void DrawWordK();
void DrawWordE();
void printStat();
void printGate();
void printTutorial();
void printFrame();
bool checkGate();
void playSound();
void stopSound();
void byebye();
void levelUpSound();
void choiceSound();
void resetData();
void initSnake();
void drawSnake();
void moveSnake(int direction);
void inputKey(int& direction);
void chooseLanguage();
void drawWall();
bool checkLose();
void drawFood();
bool isValid();
void eatFood();
void explose();
void speedUpPoint();
void checkSpeedUp();
void pauseGame();
void ThreadFunc();
void anounceQuit();
void anounceLevelUp();
void levelUp();
void drawObstacles(int level);
bool isFoodCreatedOnObstacles();
void savePlayerName();
void loadPlayerName();
void descendingScore(int arr[]);
void savePoint();
int loadRankings(int topPlayers[]);
void saveRankings(int topPlayers[]);
void outputRanking();
void saveGame(const char filePath[]);
void loadGame(const char filePath[]);
void printList();
#endif