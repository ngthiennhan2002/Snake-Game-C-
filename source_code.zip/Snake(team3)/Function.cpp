#include "Function.h"

POINT snake[25];
POINT tailSnake;
POINT food;
POINT speedUp[2];
POINT posObstacles[100];
Stat player;
int topPlayers[100] = { NULL };
load save[20] = {};

int numofSave = 0;
int STATE = 1;
int SIZE_SNAKE = 4;
int FOOD_INDEX_REMAIN = 1;
int CHAR_LOCK = LEFT;
int direction = RIGHT;
char team_3[] = "201275332012726520127559";
int SPEED = 1;
int speedUpCheck = 0;
int levelUpCheck = -1;
int pauseCheck = 0;
int language = 0; //1: Eng / 0: Vie
char date[26] = {};

void chooseOptions(int& rowMenu, int& choose)
{
	system("cls");
	while (1)
	{
		CreateMenuList(rowMenu);
		if (_kbhit()) {
			char key = _getch();
			switch (key) {
			case 'w': case 'W': {
				if (rowMenu == 23)
				{
					break;
				}
				else {
					GotoXY(68, rowMenu); cout << " ";
					rowMenu -= 2;
					GotoXY(68, rowMenu); cout << (char)16;
					choiceSound();
				}

				break;
			}
			case 's': case 'S': {
				if (rowMenu == 31)
					break;
				else {
					GotoXY(68, rowMenu); cout << " ";
					rowMenu += 2;
					GotoXY(68, rowMenu); cout << (char)16;
					choiceSound();
					break;
				}

			}
			case (char)13:
			{
				if (rowMenu == 23) {
					system("cls");
					playSound();
					resetData();
					drawWall();
					initSnake();
					ThreadFunc();
				}
				else if (rowMenu == 25) {
					system("cls");
					loadGame("fileSave.txt");
					printList();
					system("cls");
				}
				else if (rowMenu == 27) {
					system("cls");
					loadRankings(topPlayers);
					outputRanking();
					system("pause");
					system("cls");
				}
				else if (rowMenu == 29) {
					system("cls");
					chooseLanguage();
					system("cls");
				}
				else if (rowMenu == 31) {
					system("cls");
					DrawWord();
					if (language == 1)
					{
						GotoXY(62, 21);
						cout << "Are you sure to quit the game?\n"; GotoXY(58, 22);
						cout << "Enter '1' to quit, enter '0' to return\n"; GotoXY(70, 23);
						cout << "Your choice: "; cin >> choose;
						if (choose == 1) {
							GotoXY(56, 24);
							cout << "Thanks for playing our game! See you later\n";
							byebye();
							return;
						}
						else if (choose == 0) {
							system("cls");
							continue;
						}

						else {
							while (choose != 1 && choose != 0) {
								GotoXY(63, 23);
								cout << "Invalid! Please re-enter: "; cin >> choose;
								GotoXY(56, 24);
								if (choose == 1) {
									cout << "Thanks for playing our game! See you later\n";
									byebye();
									return;
								}
								else if (choose == 0) {
									system("cls");
									break;
								}
							}
						}
					}
					else {
						GotoXY(62, 21);
						cout << "Ban co chac chan muon thoat?\n"; GotoXY(60, 22);
						cout << "Nhap '1' de thoat, '0' de quay ve\n"; GotoXY(68, 23);
						cout << "Ban chon: "; cin >> choose;
						if (choose == 1) {
							GotoXY(47, 24);
							cout << "Cam on ban da trai nghiem tro choi cua chung toi. Hen gap lai ^-^\n";
							byebye();
							return;
						}
						else if (choose == 0) {
							system("cls");
							continue;
						}

						else {
							while (choose != 1 && choose != 0) {
								GotoXY(62, 23);
								cout << "Khong hop le, xin nhap lai: "; cin >> choose;
								GotoXY(47, 24);
								if (choose == 1) {
									cout << "Cam on ban da trai nghiem tro choi cua chung toi. Hen gap lai ^-^\n";
									byebye();
									return;
								}
								else if (choose == 0) {
									system("cls");
									break;
								}
							}
						}
					}
				}
			}
			}
		}
	}
}

void CreateMenuList(int& rowMenu)
{
	DrawWord();
	if (language == 1)
	{
		GotoXY(70, 20); cout << "Hello, " << player.name;
		GotoXY(70, 21); cout << "Choose the option";
		if (rowMenu == 23)
		{
			SetColor(9);
		}
		GotoXY(70, 23); cout << "1. New game";
		SetColor(4);
		if (rowMenu == 25)
		{
			SetColor(9);
		}
		GotoXY(70, 25); cout << "2. Load game";
		SetColor(4);
		if (rowMenu == 27)
		{
			SetColor(9);
		}
		GotoXY(70, 27); cout << "3. Rankings";
		SetColor(4);
		if (rowMenu == 29)
		{
			SetColor(9);
		}
		GotoXY(70, 29); cout << "4. Settings";
		SetColor(4);
		if (rowMenu == 31)
		{
			SetColor(9);
		}
		GotoXY(70, 31); cout << "5. Exit game"; SetColor(4);
		GotoXY(68, rowMenu); cout << (char)16;
		SetColor(0);
		GotoXY(62, 35); cout << " GVHD: Thay Truong Toan Thinh";
		GotoXY(71, 37); cout << "- TEAM 3 -";
		GotoXY(62, 39); cout << "Le Dang Khoa      -  20127533";
		GotoXY(62, 41); cout << "Nguyen Thien Nhan -  20127265";
		GotoXY(62, 43); cout << "Nguyen Hoang Luan -  20127559";
		
		SetColor(4);
	}
	else
	{
		GotoXY(70, 20); cout << "Xin chao, " << player.name;
		GotoXY(70, 21); cout << "Hay chon tuy chon";
		if (rowMenu == 23)
		{
			SetColor(9);
		}
		GotoXY(70, 23); cout << "1. Tro choi moi";
		SetColor(4);
		if (rowMenu == 25)
		{
			SetColor(9);
		}
		GotoXY(70, 25); cout << "2. Tiep tuc";
		SetColor(4);
		if (rowMenu == 27)
		{
			SetColor(9);
		}
		GotoXY(70, 27); cout << "3. Bang xep hang";
		SetColor(4);
		if (rowMenu == 29)
		{
			SetColor(9);
		}
		GotoXY(70, 29); cout << "4. Cai dat";
		SetColor(4);
		if (rowMenu == 31)
		{
			SetColor(9);
		}
		GotoXY(70, 31); cout << "5. Thoat tro choi"; SetColor(4);
		GotoXY(68, rowMenu); cout << (char)16;
		SetColor(0);
		GotoXY(62, 35); cout << " GVHD: Thay Truong Toan Thinh";
		GotoXY(71, 37); cout << "- NHOM 3 -";
		GotoXY(62, 39); cout << "Le Dang Khoa      -  20127533";
		GotoXY(62, 41); cout << "Nguyen Thien Nhan -  20127265";
		GotoXY(62, 43); cout << "Nguyen Hoang Luan -  20127559";
		SetColor(4);
	}
}

void DrawWord()
{
	DrawWordS();
	DrawWordN();
	DrawWordA();
	DrawWordK();
	DrawWordE();
}

void DrawWordS()
{
	GotoXY(44 - 6, 11); cout << (char)219;
	for (int i = 0; i < 13; i++)
	{
		GotoXY(44 + i - 6, 5);	cout << (char)219;
		GotoXY(44 + i - 5, 11); cout << (char)219;
		GotoXY(44 + i - 5, 17); cout << (char)219;
	}
	GotoXY(55 - 5, 4); cout << (char)219;
	GotoXY(56 - 5, 5); cout << (char)219;
	GotoXY(55 - 5, 6); cout << (char)219;
	GotoXY(44 - 5, 16); cout << (char)219;
	GotoXY(43 - 5, 17); cout << (char)219;
	GotoXY(44 - 5, 18); cout << (char)219;

	for (int i = 0; i < 5; i++)
	{
		GotoXY(43 - 5, 6 + i); cout << (char)219;
		GotoXY(56 - 5, 12 + i);	cout << (char)219;
	}
}

void DrawWordN()
{
	GotoXY(60 - 5, 5);
	for (int i = 0; i < 13; i++)
	{
		GotoXY(60 - 5, 5 + i);	cout << (char)219;
		GotoXY(73 - 5, 5 + i);	cout << (char)219;
	}
	for (int i = 0; i < 13; i++)
	{
		GotoXY(60 + i - 5, 5 + i);	cout << (char)219;
	}
}

void DrawWordA()
{
	GotoXY(84 - 5, 5);
	cout << (char)219 << (char)219 << (char)219 << (char)219;
	for (int i = 0; i < 6; i++)
	{
		GotoXY(83 - i - 5, 6 + i); cout << (char)219;
		GotoXY(88 + i - 5, 6 + i); cout << (char)219;
	}
	for (int i = 0; i < 5; i++)
	{
		GotoXY(78 + i - 5, 11 + i);  cout << (char)219;
		GotoXY(93 - i - 5, 11 + i);  cout << (char)219;
	}
	for (int i = 0; i < 3; i++)
	{
		GotoXY(82 - 5, 15 + i);  cout << (char)219;
		GotoXY(89 - 5, 15 + i);  cout << (char)219;
	}
	GotoXY(85 - 5, 11); cout << (char)219 << (char)219;
}

void DrawWordK()
{
	for (int i = 0; i < 13; i++)
	{
		GotoXY(92, 5 + i);  cout << (char)219;
	}
	GotoXY(93, 11); cout << (char)219;
	for (int i = 0; i < 6; i++)
	{
		GotoXY(94 + i, 10 - i); cout << (char)219;
		GotoXY(94 + i, 12 + i); cout << (char)219;
	}
}

void DrawWordE()
{
	GotoXY(104, 5); cout << (char)219;
	GotoXY(104, 17); cout << (char)219;
	for (int i = 0; i < 11; i++)
	{
		GotoXY(104, 6 + i); cout << (char)219;
	}
	for (int i = 0; i < 10; i++)
	{
		GotoXY(105 + i, 5); cout << (char)219;
		GotoXY(105 + i, 11); cout << (char)219;
		GotoXY(105 + i, 17); cout << (char)219;
	}
}
void SetColor(int ForgC)
{
	WORD wColor;
	HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	if (GetConsoleScreenBufferInfo(hStdOut, &csbi))
	{
		wColor = (csbi.wAttributes & 0xF0) + (ForgC & 0x0F);
		SetConsoleTextAttribute(hStdOut, wColor);
	}
	return;
}

void ClearConsoleToColors(int ForgC, int BackC)
{
	WORD wColor = ((BackC & 0x0F) << 4) + (ForgC & 0x0F);
	HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD coord = { 0, 0 };
	DWORD count;
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	SetConsoleTextAttribute(hStdOut, wColor);
	if (GetConsoleScreenBufferInfo(hStdOut, &csbi))
	{
		FillConsoleOutputCharacter(hStdOut, (TCHAR)32, csbi.dwSize.X * csbi.dwSize.Y, coord, &count);
		FillConsoleOutputAttribute(hStdOut, csbi.wAttributes, csbi.dwSize.X * csbi.dwSize.Y, coord, &count);
		SetConsoleCursorPosition(hStdOut, coord);
	}
	return;
}
void FixConsoleWindow()
{
	HWND consoleWindow = GetConsoleWindow();
	LONG style = GetWindowLong(consoleWindow, GWL_STYLE);
	style = style & ~(WS_MAXIMIZEBOX) & ~(WS_THICKFRAME);
	SetWindowLong(consoleWindow, GWL_STYLE, style);
}

void ResizeConsole(int width, int height)
{
	HWND console = GetConsoleWindow();
	RECT r;
	GetWindowRect(console, &r);
	MoveWindow(console, r.left, r.top, width, height, TRUE);
}
void setFontSize(int FontSize)

{
	CONSOLE_FONT_INFOEX info = { 0 };
	info.cbSize = sizeof(info);
	info.dwFontSize.Y = FontSize;
	info.FontWeight = FW_NORMAL;
	wcscpy_s(info.FaceName, L"Lucida Console");
	SetCurrentConsoleFontEx(GetStdHandle(STD_OUTPUT_HANDLE), NULL, &info);
}
void noCursorType()
{
	CONSOLE_CURSOR_INFO info;
	info.bVisible = FALSE;
	info.dwSize = 20;
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &info);
}
void GotoXY(int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
void resetData()
{
	CHAR_LOCK = LEFT, direction = RIGHT, SPEED = 1; FOOD_INDEX_REMAIN = 3, SIZE_SNAKE = 4; speedUpCheck = 0; levelUpCheck = -1;
	STATE = 1; food = { NULL,NULL };
	snake[0] = { WALL_LEFT + 1 , WALL_UP + 2 };
	for (int i = 0; i < MAX_SIZE_SNAKE; i++)
	{
		if (snake[i].x != NULL)
			snake[i].x = NULL;
		if (snake[i].y != NULL)
			snake[i].y = NULL;
	}
}
void initSnake()
{
	snake[0] = { WALL_LEFT + 1 , WALL_UP + 2 };
}
void drawSnake()
{
	for (int i = 0; i < SIZE_SNAKE; i++)
	{
		if (levelUpCheck == 1)
		{
			for (int i = 0; i <= SIZE_SNAKE; i++)
			{
				GotoXY(210 - i, 49);
				cout << " ";
			}
		}
		SetColor(2);
		GotoXY(snake[i].x, snake[i].y);
		cout << team_3[i];
		SetColor(4);
	}
	GotoXY(tailSnake.x, tailSnake.y);
	cout << " ";
	GotoXY(210, 49);
	cout << " ";
}
void moveSnake(int direction)
{
	tailSnake = snake[SIZE_SNAKE - 1];
	for (int i = SIZE_SNAKE - 1; i >= 1; i--)
	{
		snake[i] = snake[i - 1];
	}
	switch (direction)
	{
	case UP:
	{
		snake[0].y--;
		break;
	}
	case DOWN:
	{
		snake[0].y++;
		break;
	}
	case LEFT:
	{
		snake[0].x--;
		break;
	}
	case RIGHT:
	{
		snake[0].x++;
		break;
	}
	}
}
void inputKey(int& direction)
{
	if (_kbhit())
	{
		int key = toupper(_getch());
		switch (key)
		{
		case 'W':
		{
			if (CHAR_LOCK != UP)
			{
				direction = UP;
				CHAR_LOCK = DOWN;
			}
			break;
		}
		case 'S':
		{
			if (CHAR_LOCK != DOWN)
			{
				direction = DOWN;
				CHAR_LOCK = UP;
			}
			break;
		}
		case 'A':
		{
			if (CHAR_LOCK != LEFT)
			{
				direction = LEFT;
				CHAR_LOCK = RIGHT;
			}
			break;
		}
		case 'D':
		{
			if (CHAR_LOCK != RIGHT)
			{
				direction = RIGHT;
				CHAR_LOCK = LEFT;
			}
			break;
		}
		case 'N':
		{
			playSound();
			break;
		}
		case 'M':
		{
			stopSound();
			break;
		}
		case 'P':
		{
			pauseCheck = 1;
			pauseGame();
			break;
		}
		case 'L':
		{
			saveGame("fileSave.txt");
			break;
		}
		case 27:
		{
			printFrame();
			anounceQuit();
			system("cls");
			drawWall();
		}
		}
	}
}
void pauseGame()
{
	while (pauseCheck)
	{
		printStat();
		if (_kbhit())
		{
			int temp = toupper(_getch());
			if ((temp != CHAR_LOCK) && (temp == 'D' || temp == 'A' || temp == 'W' || temp == 'S'))
			{
				if (temp == 'D') CHAR_LOCK = 'A';
				else if (temp == 'W') CHAR_LOCK = 'S';
				else if (temp == 'S') CHAR_LOCK = 'W';
				else CHAR_LOCK = 'D';
				direction = temp;
				pauseCheck = 0;
			}
			else
			{
				if (temp == CHAR_LOCK)	pauseCheck = 0;
				else {
					switch (temp)
					{
					case 'N':
					{
						playSound();
						break;
					}
					case 'M':
					{
						stopSound();
						break;
					}
					case 'P':
					{
						pauseGame();
						break;
					}
					case 'L':
					{
						saveGame("fileSave.txt");
						break;
					}
					}
				}
			}
		}
		printStat();
	}
}

void drawWall()
{
	for (int i = WALL_LEFT; i <= WALL_RIGHT; i++)
	{
		GotoXY(i, WALL_UP);
		cout << (char)220;
	}
	for (int i = WALL_UP + 1; i <= WALL_DOWN; i++)
	{
		GotoXY(WALL_LEFT, i);
		cout << (char)221;
	}
	for (int i = WALL_LEFT; i <= WALL_RIGHT; i++)
	{
		GotoXY(i, WALL_DOWN);
		cout << (char)223;
	}
	for (int i = WALL_UP + 1; i <= WALL_DOWN - 1; i++)
	{
		GotoXY(WALL_RIGHT, i);
		cout << (char)222;
	}
	drawObstacles(SPEED);
	SetColor(17);
	GotoXY(WALL_RIGHT + 10, WALL_UP);
	cout << (char)201;
	GotoXY(WALL_RIGHT + 61, WALL_UP);
	cout << (char)187;
	GotoXY(WALL_RIGHT + 10, WALL_UP + 15);
	cout << (char)200;
	GotoXY(WALL_RIGHT + 61, WALL_UP + 15);
	cout << (char)188;

	for (int i = WALL_RIGHT + 11; i <= WALL_RIGHT + 60; i++)
	{
		GotoXY(i, WALL_UP);
		cout << (char)205;
	}
	for (int i = WALL_UP + 1; i <= WALL_UP + 14; i++)
	{
		GotoXY(WALL_RIGHT + 10, i);
		cout << (char)186;
	}
	for (int i = WALL_RIGHT + 11; i <= WALL_RIGHT + 60; i++)
	{
		GotoXY(i, WALL_UP + 15);
		cout << (char)205;
	}
	for (int i = WALL_UP + 1; i <= WALL_UP + 14; i++)
	{
		GotoXY(WALL_RIGHT + 61, i);
		cout << (char)186;
	}
	SetColor(4);
	SetColor(0);
	GotoXY(WALL_RIGHT + 10, WALL_UP + 17);
	cout << (char)201;
	GotoXY(WALL_RIGHT + 61, WALL_UP + 17);
	cout << (char)187;
	GotoXY(WALL_RIGHT + 10, WALL_DOWN);
	cout << (char)200;
	GotoXY(WALL_RIGHT + 61, WALL_DOWN);
	cout << (char)188;

	for (int i = WALL_RIGHT + 11; i <= WALL_RIGHT + 60; i++)
	{
		GotoXY(i, WALL_UP + 17);
		cout << (char)205;
	}
	for (int i = WALL_UP + 18; i <= WALL_DOWN - 1; i++)
	{
		GotoXY(WALL_RIGHT + 10, i);
		cout << (char)186;
	}
	for (int i = WALL_RIGHT + 11; i <= WALL_RIGHT + 60; i++)
	{
		GotoXY(i, WALL_DOWN);
		cout << (char)205;
	}
	for (int i = WALL_UP + 18; i <= WALL_DOWN - 1; i++)
	{
		GotoXY(WALL_RIGHT + 61, i);
		cout << (char)186;
	}
	printTutorial();
	SetColor(4);
}
void printFrame()
{
	SetColor(0);
	GotoXY(WALL_LEFT + 30, WALL_UP + 10);
	cout << (char)201;
	GotoXY(WALL_LEFT + 80, WALL_UP + 10);
	cout << (char)187;
	GotoXY(WALL_LEFT + 30, WALL_UP + 20);
	cout << (char)200;
	GotoXY(WALL_LEFT + 80, WALL_UP + 20);
	cout << (char)188;
	for (int i = WALL_LEFT + 31; i <= WALL_LEFT + 79; i++)
	{
		GotoXY(i, WALL_UP + 10);
		cout << (char)205;
	}
	for (int i = WALL_UP + 11; i <= WALL_UP + 19; i++)
	{
		GotoXY(WALL_LEFT + 30, i);
		cout << (char)186;
	}
	for (int i = WALL_LEFT + 31; i <= WALL_LEFT + 79; i++)
	{
		GotoXY(i, WALL_UP + 20);
		cout << (char)205;
	}
	for (int i = WALL_UP + 11; i <= WALL_UP + 19; i++)
	{
		GotoXY(WALL_LEFT + 80, i);
		cout << (char)186;
	}
	SetColor(4);
}

void anounceQuit()
{
	if (language == 1)
	{
		GotoXY(WALL_LEFT + 40, WALL_UP + 11);
		cout << "Are you sure you want to exit ?" << endl;
		GotoXY(WALL_LEFT + 43, WALL_UP + 13);
		cout << "YOUR PROCESS WILL BE LOST" << endl;
		GotoXY(WALL_LEFT + 45, WALL_UP + 17);
		cout << "ENTER\t\t   " << "ESC" << endl;
		int check = 1;
		while (check == 1)
		{
			if (_kbhit())
			{
				int temp = toupper(_getch());
				switch (temp)
				{
				case 27: check = 0; break;
				case 13: check = 0; STATE = -1; break;
				default: break;
				}
			}
		}
	}
	else {
		GotoXY(WALL_LEFT + 40, WALL_UP + 11);
		cout << "Ban co chac chan muon thoat ?" << endl;
		GotoXY(WALL_LEFT + 43, WALL_UP + 13);
		cout << "DU LIEU CUA BAN SE MAT" << endl;
		GotoXY(WALL_LEFT + 45, WALL_UP + 17);
		cout << "ENTER\t\t   " << "ESC" << endl;
		int check = 1;
		while (check == 1)
		{
			if (_kbhit())
			{
				int temp = toupper(_getch());
				switch (temp)
				{
				case 27: check = 0; break;
				case 13: check = 0; STATE = -1; stopSound(); break;
				default: break;
				}
			}
		}
	}
}
void printTutorial()
{
	if (language == 1)
	{
		GotoXY(WALL_RIGHT + 30, WALL_UP + 18);
		cout << "TUTORIAL";
		GotoXY(WALL_RIGHT + 14, WALL_UP + 20);
		cout << "W : Moving Up" << "\t\tS : Moving Down";
		GotoXY(WALL_RIGHT + 14, WALL_UP + 22);
		cout << "A : Moving Left" << "\t\tD : Moving Right";
		GotoXY(WALL_RIGHT + 14, WALL_UP + 24);
		cout << "P : Pause Game" << "\t\tL : Save Game";
		GotoXY(WALL_RIGHT + 14, WALL_UP + 26);
		cout << "N : Play music" << "\t\tM : Mute music";
		GotoXY(WALL_RIGHT + 14, WALL_UP + 28);
		cout << "ESC: Return Menu";
	}
	else {
		GotoXY(WALL_RIGHT + 30, WALL_UP + 18);
		cout << "HUONG DAN";
		GotoXY(WALL_RIGHT + 14, WALL_UP + 20);
		cout << "W : Di len" << "\t\tS : Di xuong";
		GotoXY(WALL_RIGHT + 14, WALL_UP + 22);
		cout << "A : Sang trai" << "\t\tD : Sang phai";
		GotoXY(WALL_RIGHT + 14, WALL_UP + 24);
		cout << "P : Tam dung" << "\t\tL : Luu tro choi";
		GotoXY(WALL_RIGHT + 14, WALL_UP + 26);
		cout << "N : Mo nhac" << "\t\tM : Tat nhac";
		GotoXY(WALL_RIGHT + 14, WALL_UP + 28);
		cout << "ESC: Tro ve man hinh chinh";
	}
}
void printGate()
{

	GotoXY(WALL_LEFT - 1, WALL_UP + 2);
	cout << (char)221;
	GotoXY(WALL_LEFT - 1, WALL_UP + 1);
	cout << (char)220 << (char)220;
	GotoXY(WALL_LEFT - 1, WALL_UP + 3);
	cout << (char)223 << (char)223;
	GotoXY(WALL_LEFT, WALL_UP + 2);
	SetColor(rand());
	cout << (char)177;
	SetColor(4);
	if (!checkGate())
	{
		drawWall();
	}
}
bool checkLose()
{
	for (int i = 1; i < SIZE_SNAKE; i++)
	{
		if (snake[i].x == snake[0].x && snake[i].y == snake[0].y)
			return true;
	}
	if (levelUpCheck == 0 || levelUpCheck == -1)
	{
		if (snake[0].y == WALL_UP || snake[0].y == WALL_DOWN || snake[0].x == WALL_LEFT || snake[0].x == WALL_RIGHT)
			return true;
	}
	else
	{
		if (snake[0].y == WALL_UP + 2 && snake[0].x == WALL_LEFT)
		{
			return false;
		}
		else
		{
			if (snake[0].y == WALL_UP || snake[0].y == WALL_DOWN || snake[0].x == WALL_LEFT || snake[0].x == WALL_RIGHT)
			{
				return true;
			}
		}
	}
	if (SPEED != 1)
	{
		int x = -1;
		int level = SPEED;
		if (speedUpCheck == 1)
		{
			level -= 3;
		}
		switch (level)
		{
		case 2: x = 50; break;
		case 3: x = 50; break;
		case 4: x = 100; break;
		}
		for (int i = 0; i < x; i++)
		{
			if (posObstacles != NULL) {
				if (snake[0].x == posObstacles[i].x && snake[0].y == posObstacles[i].y)
					return true;
			}
		}
	}
	return false;
}
void drawFood()
{
	while (isValid() == false)
	{
		food.x = rand() % (WALL_RIGHT - WALL_LEFT - 1) + WALL_LEFT + 1;
		food.y = rand() % (WALL_DOWN - WALL_UP - 1) + WALL_UP + 1;
		if (isFoodCreatedOnObstacles() == true)
			continue;
		else break;
	}
	if (FOOD_INDEX_REMAIN == 0)return;
	GotoXY(food.x, food.y);
	cout << (char)254;
}
bool isValid()
{
	for (int i = 0; i < SIZE_SNAKE; i++)
	{
		if ((food.x == snake[i].x && food.y == snake[i].y) || (food.x == speedUp[0].x && food.y == speedUp[0].y) || (food.x == speedUp[1].x && food.y == speedUp[1].y) || food.x == NULL || food.y == NULL)
		{
			return false;
		}
	}

	return true;
}
void eatFood()
{
	if (snake[0].x == food.x && snake[0].y == food.y)
	{
		SIZE_SNAKE++;
		player.score++;
		FOOD_INDEX_REMAIN--;
		if (FOOD_INDEX_REMAIN <= 0)
			FOOD_INDEX_REMAIN = 0;
		food.x = food.y = NULL;
	}
}
bool checkGate()
{
	if (tailSnake.x == NULL)
	{
		levelUpCheck = -1;
		return true;
	}
	if (FOOD_INDEX_REMAIN <= 0)
	{
		levelUpCheck = 1;
		return true;
	}
	return false;
}
void explose()
{
	int y = snake[0].y;
	int x = snake[0].x;
	int tempX = x;
	int tempY = y;

	GotoXY(x, y);
	cout << "@";
	x--; y--;
	Sleep(250);
	for (int j = y; j < snake[0].y + 2; j++)
	{
		for (int i = x; i < snake[0].x + 2; i++)
		{
			GotoXY(i, j);
			cout << "#";
		}
		cout << endl;
	}
	Sleep(250);
	GotoXY(tempX, tempY);
	cout << " ";
	x--; y--;
	for (int j = y; j < snake[0].y + 3; j++)
	{
		for (int i = x; i < snake[0].x + 3; i++)
		{
			GotoXY(i, j);
			cout << "*";
		}
		cout << endl;
	}
	x++; y++;
	Sleep(250);
	for (int j = y; j < snake[0].y + 2; j++)
	{
		for (int i = x; i < snake[0].x + 2; i++)
		{
			GotoXY(i, j);
			cout << " ";
		}
		cout << endl;
	}
	x--; y--;
	Sleep(250);
	for (int j = y; j < snake[0].y + 3; j++)
	{
		for (int i = x; i < snake[0].x + 3; i++)
		{
			GotoXY(i, j);
			cout << " ";
		}
		cout << endl;
	}
}
void ThreadFunc()
{
	while (STATE == 1)
	{
		drawFood();
		Sleep(150 / SPEED);
		checkSpeedUp();
		inputKey(direction);
		moveSnake(direction);
		if (levelUpCheck == -1)
		{
			printGate();
		}
		if (levelUpCheck == 1)
		{
			printGate();
			levelUp();
		}
		drawSnake();
		eatFood();
		printStat();
		if (checkLose())
		{
			STATE = 0;
		}	
		pauseGame();
	}
	if (checkLose())
	{
		savePoint();
		loadRankings(topPlayers);
		saveRankings(topPlayers);
		bool isPlay = PlaySound(L"game over.wav", NULL, SND_FILENAME | SND_ASYNC);
		explose();
		printFrame();
		if (language == 1)
		{
			GotoXY(WALL_LEFT + 52, WALL_UP + 11);
			cout << "HUHUHUH" << endl;
			GotoXY(WALL_LEFT + 51, WALL_UP + 14);
			cout << "You lose!!" << endl;
			GotoXY(WALL_LEFT + 30, WALL_UP + 17);
			cout << "\t\tPress ENTER to return menu";
		}
		else {
			GotoXY(WALL_LEFT + 52, WALL_UP + 11);
			cout << "HUHUHUH" << endl;
			GotoXY(WALL_LEFT + 49, WALL_UP + 14);
			cout << "Ban da chet!!" << endl;
			GotoXY(WALL_LEFT + 32, WALL_UP + 17);
			cout << "\t   Nhan ENTER de tro ve man hinh chinh";
		}
		int check = 1;
		while (check == 1)
		{
			if (_kbhit())
			{
				int temp = toupper(_getch());
				switch (temp)
				{
				case 13: check = 0; STATE = -1; break;
				default: break;
				}
			}
		}
	}
	system("cls");
}
void printStat()
{
	if (language == 1)
	{
		GotoXY(WALL_RIGHT + 30, WALL_UP + 1);
		cout << "STATISTICS";
		GotoXY(WALL_RIGHT + 12, WALL_UP + 3);
		cout << "Player name: " << player.name << endl;
		player.speed = SPEED;
		if (speedUpCheck == 1)
		{
			player.speed -= 3;
		}
		GotoXY(WALL_RIGHT + 12, WALL_UP + 5);
		cout << "Score: " << player.score << endl;
		GotoXY(WALL_RIGHT + 12, WALL_UP + 7);
		cout << "Levels: " << player.speed << endl;
		GotoXY(WALL_RIGHT + 12, WALL_UP + 9);
		cout << "Lives: " << (char)3 << endl;
		GotoXY(WALL_RIGHT + 12, WALL_UP + 11);
		if (FOOD_INDEX_REMAIN == 0)
		{
			SetColor(rand());
			cout << "Go to the gate to reach new levels!!!";
			SetColor(4);
		}
		else
		{
			cout << "Need " << FOOD_INDEX_REMAIN << " Food(s) to reach new levels" << endl;
		}
		if (pauseCheck == 1)
		{
			GotoXY(WALL_RIGHT + 27, WALL_UP + 13);
			SetColor(rand());
			Sleep(200);
			cout << "GAME WAS PAUSED!";
			Sleep(0);
			SetColor(4);
		}
		else
		{
			GotoXY(WALL_RIGHT + 27, WALL_UP + 13);
			cout << "                ";
		}
	}
	else
	{
		GotoXY(WALL_RIGHT + 30, WALL_UP + 1);
		cout << "THONG SO";
		GotoXY(WALL_RIGHT + 12, WALL_UP + 3);
		cout << "Ten nguoi choi: " << player.name << endl;
		player.speed = SPEED;
		GotoXY(WALL_RIGHT + 12, WALL_UP + 5);
		cout << "Diem: " << player.score << endl;
		GotoXY(WALL_RIGHT + 12, WALL_UP + 7);
		player.speed = SPEED;
		if (speedUpCheck == 1)
		{
			player.speed -= 3;
		}
		cout << "Cap do: " << player.speed << endl;
		GotoXY(WALL_RIGHT + 12, WALL_UP + 9);
		cout << "Mang: " << (char)3 << endl;
		GotoXY(WALL_RIGHT + 12, WALL_UP + 11);
		if (FOOD_INDEX_REMAIN == 0)
		{
			SetColor(rand());
			cout << "Di qua cong de len cap !!!!";
			SetColor(4);
		}
		else
		{
			cout << "Can " << FOOD_INDEX_REMAIN << " Thuc an de len cap " << endl;
		}
		if (pauseCheck == 1)
		{
			GotoXY(WALL_RIGHT + 24, WALL_UP + 13);
			SetColor(rand());
			Sleep(200);
			cout << "TRO CHOI DANG TAM DUNG!";
			Sleep(0);
			SetColor(4);
		}
		else
		{
			GotoXY(WALL_RIGHT + 24, WALL_UP + 13);
			cout << "                       ";
		}
	}
}
void speedUpPoint()
{
	SetColor(rand());
	speedUp[0].x = WALL_LEFT + 10;
	speedUp[0].y = WALL_UP + 5;
	speedUp[1].x = WALL_RIGHT - 20;
	speedUp[1].y = WALL_DOWN - 7;
	GotoXY(speedUp[0].x, speedUp[0].y);
	cout << (char)175 << (char)175;
	GotoXY(speedUp[1].x, speedUp[1].y);
	cout << (char)174 << (char)174;
	SetColor(4);
}
void checkSpeedUp()
{
	speedUpPoint();
	if (snake[0].x == speedUp[0].x + 1 && snake[0].y == speedUp[0].y && speedUpCheck == 0)
	{
		if (snake[1].x == speedUp[0].x && snake[1].y == speedUp[0].y)
		{
			SPEED += 3;
			speedUpCheck = 1;
		}
	}
	if (snake[0].x == speedUp[1].x && snake[0].y == speedUp[1].y && speedUpCheck == 0)
	{
		if (snake[1].x == speedUp[1].x + 1 && snake[0].y == speedUp[1].y)
		{
			SPEED += 3;
			speedUpCheck = 1;
		}
	}
	if ((snake[0].x == WALL_LEFT + 55 || snake[0].y == WALL_UP + 15) && speedUpCheck == 1)
	{
		SPEED -= 3;
		speedUpCheck = 0;
	}
}
void playSound()
{
	bool isPlay = PlaySound(L"during game.wav", NULL, SND_FILENAME | SND_LOOP | SND_ASYNC);
}
void byebye()
{
	bool byeSound = PlaySound(L"byebye.wav", NULL, SND_FILENAME);
}
void levelUpSound()
{
	bool lvUpSound = PlaySound(L"levelup.wav", NULL, SND_FILENAME | SND_ASYNC);
}
void choiceSound()
{
	bool choiceSound = PlaySound(L"choice.wav", NULL, SND_FILENAME | SND_ASYNC);
}
void stopSound()
{
	bool isPlay = PlaySound(NULL, NULL, NULL);
}
void levelUp()
{
	if (levelUpCheck == 1 && FOOD_INDEX_REMAIN == 0)
	{
		if (snake[0].x == WALL_LEFT && snake[0].y == WALL_UP + 2)
		{
			snake[0] = { 210,49 };
		}
		if (tailSnake.x == 210 && tailSnake.y == 49)
		{
			snake[0] = { WALL_LEFT + 1,WALL_UP + 2 };
			for (int i = 1; i < SIZE_SNAKE; i++)
			{
				snake[i].x = snake[i].y = NULL;
			}
			levelUpSound();
			levelUpSound();
			printFrame();
			anounceLevelUp();
			system("cls");
			SPEED++;
			levelUpCheck = -1;
			FOOD_INDEX_REMAIN = 4;
			direction = RIGHT;
			CHAR_LOCK = LEFT;
			food.x = food.y = NULL;
			drawWall();
		}
	}
}
void anounceLevelUp()
{
	if (language == 1)
	{
		GotoXY(WALL_LEFT + 38, WALL_UP + 11);
		cout << "Congratulations for completing level " << SPEED << endl;
		GotoXY(WALL_LEFT + 38, WALL_UP + 14);
		cout << "Are you ready for the next challenger ?" << endl;
		GotoXY(WALL_LEFT + 50, WALL_UP + 17);
		cout << "\tENTER";
	}
	else {
		GotoXY(WALL_LEFT + 43, WALL_UP + 11);
		cout << "Chuc mung ban vuot qua cap " << SPEED << endl;
		GotoXY(WALL_LEFT + 37, WALL_UP + 14);
		cout << "Ban da sang sang cho thu thach moi chua ?" << endl;
		GotoXY(WALL_LEFT + 50, WALL_UP + 17);
		cout << "\tENTER";
	}
	int check = 1;
	while (check == 1)
	{
		if (_kbhit())
		{
			int temp = toupper(_getch());
			switch (temp)
			{
			case 13: check = 0; STATE = 1; choiceSound(); playSound(); break;
			default: break;
			}
		}
	}
}

void drawObstacles(int level)
{
	if (speedUpCheck == 1)
	{
		level -= 3;
	}
	if (level == 2) {
		for (int i = 0; i < 10; i++)
		{
			posObstacles[i] = { 60, 6 + i };
			GotoXY(posObstacles[i].x, posObstacles[i].y);  cout << (char)178;
			posObstacles[i + 10] = { 63, 6 + i };
			GotoXY(posObstacles[i + 10].x, posObstacles[i].y);  cout << (char)178;
			posObstacles[i + 20] = { 66, 6 + i };
			GotoXY(posObstacles[i + 20].x, posObstacles[i].y);  cout << (char)178;
			posObstacles[i + 30] = { 69, 6 + i };
			GotoXY(posObstacles[i + 30].x, posObstacles[i].y);  cout << (char)178;
			posObstacles[i + 40] = { 72, 6 + i };
			GotoXY(posObstacles[i + 40].x, posObstacles[i].y);  cout << (char)178;
		}
	}
	else if (level == 3) {
		int temp = WALL_DOWN;
		for (int i = 0; i < 10; i++)
		{
			posObstacles[i] = { 45, 6 + i };
			GotoXY(posObstacles[i].x, posObstacles[i].y);  cout << (char)178;
			posObstacles[i + 10] = { 50, WALL_DOWN - i - 1 };
			GotoXY(posObstacles[i + 10].x, posObstacles[i + 10].y);  cout << (char)178;
			posObstacles[i + 20] = { 55, 6 + i };
			GotoXY(posObstacles[i + 20].x, posObstacles[i + 20].y);  cout << (char)178;
			posObstacles[i + 30] = { 60, WALL_DOWN - i - 1 };
			GotoXY(posObstacles[i + 30].x, posObstacles[i + 30].y);  cout << (char)178;
			posObstacles[i + 40] = { 65, 6 + i };
			GotoXY(posObstacles[i + 40].x, posObstacles[i + 40].y);  cout << (char)178;
		}
	}
	else if (level == 4)
	{
		int temp = (WALL_DOWN - WALL_UP) / 2;
		for (int i = 0; i < 10; i++)
		{
			posObstacles[i] = { 50, temp + i };
			GotoXY(posObstacles[i].x, posObstacles[i].y);  cout << (char)178;
			posObstacles[i + 10] = { 50 + i, temp };
			GotoXY(posObstacles[i + 10].x, posObstacles[i + 10].y);  cout << (char)178;
			posObstacles[i + 20] = { 50 + i, temp + 9 };
			GotoXY(posObstacles[i + 20].x, posObstacles[i + 20].y);  cout << (char)178;
			posObstacles[i + 30] = { 79, temp + i };
			GotoXY(posObstacles[i + 30].x, posObstacles[i + 30].y);  cout << (char)178;
			posObstacles[i + 40] = { 70 + i, temp };
			GotoXY(posObstacles[i + 40].x, posObstacles[i + 40].y);  cout << (char)178;
			posObstacles[i + 50] = { 70 + i, temp + 9 };
			GotoXY(posObstacles[i + 50].x, posObstacles[i + 50].y);  cout << (char)178;
		}
		for (int i = 0; i < 10; i++)
		{
			posObstacles[i + 60] = { 60 + i, temp - 2 };
			GotoXY(posObstacles[i + 60].x, posObstacles[i + 60].y);  cout << (char)178;
			posObstacles[i + 70] = { 60 + i, temp + 11 };
			GotoXY(posObstacles[i + 70].x, posObstacles[i + 70].y);  cout << (char)178;
			posObstacles[i + 80] = { NULL };
			posObstacles[i + 90] = { NULL };
		}
	}
}

bool isFoodCreatedOnObstacles()
{
	int k = -1;
	int level = SPEED;
	if (speedUpCheck == 1)
	{
		level -= 3;
	}
	switch (level)
	{
	case 2: k = 50; break;
	case 3: k = 50; break;
	case 4: k = 100; break;
	}
	for (int i = 0; i <= k; i++)
	{
		if (food.x == posObstacles[i].x && food.y == posObstacles[i].y)
			return true;
	}
	return false;
}

void savePlayerName()
{
	fstream file;
	file.open("Name.txt", ios::out);
	if (file.fail())
	{
		cout << "Fail to save name\n";
		return;
	}
	else {
		file << player.name;
	}
	file.close();
}

void loadPlayerName()
{
	int row = 10;
	fstream file;
	file.open("Name.txt", ios::in);
	if (file.fail())
	{
		cout << "Fail to load name\n";
		return;
	}
	else {
		getline(file, player.name);
		if (player.name == "")
		{
			printFrame();
			GotoXY(WALL_LEFT + 32, WALL_UP + 11);
			if (language == 1)
			{
				cout << "Enter your name: ";
			}
			else {
				cout << "Nhap ten cua ban: ";
			}
			getline(cin, player.name);
			savePlayerName();
			system("cls");
		}
		else {
			int choose;
			printFrame();
			if (language == 1)
			{
				GotoXY(WALL_LEFT + 32, WALL_UP + 11);
				cout << "Your last player name was: " << player.name;
				GotoXY(WALL_LEFT + 32, WALL_UP + 13);
				cout << "Do you want to continue with this name?";
				GotoXY(WALL_LEFT + 32, WALL_UP + 15);
				cout << "Choose 1 to change name, choose 0 to stay";
				GotoXY(WALL_LEFT + 32, WALL_UP + 17);
				cout << "Enter your choice: "; cin >> choose;
				while (1)
				{
					if (choose == 1) {
						system("cls");
						printFrame();
						GotoXY(WALL_LEFT + 32, WALL_UP + 11);
						cout << "Enter your name: "; cin.ignore(); getline(cin, player.name);
						savePlayerName();
						system("cls");
						return;
					}
					else if (choose == 0) {
						system("cls");
						return;
					}
					else {
						GotoXY(WALL_LEFT + 32, WALL_UP + 17);
						cout << "Wrong input! Try again: "; cin >> choose;
					}
				}
			}
			else
			{
				GotoXY(WALL_LEFT + 32, WALL_UP + 11);
				cout << "Ten ban la: " << player.name;
				GotoXY(WALL_LEFT + 32, WALL_UP + 13);
				cout << "Ban co muon tiep tuc voi ten nay?";
				GotoXY(WALL_LEFT + 32, WALL_UP + 15);
				cout << "Chon 1 de doi ten, chon 0 de giu nguyen";
				GotoXY(WALL_LEFT + 32, WALL_UP + 17);
				cout << "Ban chon: "; cin >> choose;
				cin.ignore(1);
				while (1)
				{
					if (choose == 1) {
						system("cls");
						printFrame();
						GotoXY(WALL_LEFT + 32, WALL_UP + 11);
						cout << "Nhap ten cua ban: "; getline(cin, player.name);
						savePlayerName();
						system("cls");
						return;
					}
					else if (choose == 0) {
						system("cls");
						return;
					}
					else {
						GotoXY(WALL_LEFT + 32, WALL_UP + 17);
						cout << "Khong hop le, xin nhap lai: "; cin >> choose;
					}
				}
			}
		}
	}
	file.close();
}


void descendingScore(int arr[])
{
	int tg;
	for (int i = 0; i < 5; i++) {
		for (int j = i + 1; j < 6; j++) {
			if (arr[i] < arr[j]) {
				tg = arr[i];
				arr[i] = arr[j];
				arr[j] = tg;
			}
		}
	}
}

void savePoint() {
	fstream file;
	file.open("Rankings.txt", ios::out | ios::app);
	if (file.fail())
	{
		cout << "Fail to open file"; return;
	}
	else {
		file << player.score << " ";
	}
	file.close();
}

int loadRankings(int topPlayers[])
{
	int count = 0;
	fstream file;
	file.open("Rankings.txt", ios::in);
	if (file.fail())
	{
		cout << "Fail to open file"; return -1;
	}
	else {
		while (!file.eof()) {
			file >> topPlayers[count];
			count++;
		}
		descendingScore(topPlayers);
	}
	file.close();
	return count;
}

void saveRankings(int topPlayers[])
{
	fstream file;
	file.open("Rankings.txt", ios::out);
	if (file.fail())
	{
		cout << "Fail to open file"; return;
	}
	else {
		for (int i = 0; i < 5; i++)
		{
			file << topPlayers[i] << endl;
		}
	}
	file.close();
}

void outputRanking()
{
	int row = 5;
	if (language == 1) {
		GotoXY(40, 5); cout << "LEADERBOARD: ";
		for (int i = 0; i < 5; i++)
		{
			row += 3;
			GotoXY(37, row); cout << "Top " << i + 1 << ": " << topPlayers[i];
		}
		GotoXY(37, row + 3);
	}
	else {
		GotoXY(40, 5); cout << "BANG XEP HANG: ";
		for (int i = 0; i < 5; i++)
		{
			row += 3;
			GotoXY(37, row); cout << "Hang " << i + 1 << ": " << topPlayers[i];
		}
		GotoXY(37, row + 3);
	}
}
void chooseLanguage()
{

	DrawWord();
	int rowMenu = 25;
	int check = 1;
	while (check)
	{

		GotoXY(69, 23);
		if (language == 1)
		{
			cout << "Choose Language:";
		}
		else
		{
			cout << "Chon Ngon ngu:";
		}
		GotoXY(68, 25);
		if (rowMenu == 25)
			SetColor(9);
		cout << "Tieng Viet";
		SetColor(4);
		GotoXY(68, 27);
		if (rowMenu == 27)
			SetColor(9);
		cout << "English";
		SetColor(4);
		GotoXY(67, rowMenu);
		cout << (char)16;
		if (_kbhit())
		{
			int key = _getch();
			switch (key)
			{
			case 'W':case 'w':
			{
				if (rowMenu == 25)
				{
					break;
				}
				GotoXY(67, rowMenu);
				cout << " ";
				rowMenu -= 2;
				GotoXY(67, rowMenu);
				cout << (char)16;
				choiceSound();
				break;
			}
			case 'S':case 's':
			{
				if (rowMenu == 27)
				{
					break;
				}
				GotoXY(67, rowMenu);
				cout << " ";
				rowMenu += 2;
				GotoXY(67, rowMenu);
				cout << (char)16;
				choiceSound();
				break;
			}
			case (char)13:
			{
				if (rowMenu == 25)
				{
					language = 0;
					check = 0;
				}
				else
				{
					language = 1;
					check = 0;
				}
				break;
			}
			}
		}
	}
}
void saveGame(const char filePath[])
{
	time_t now = time(NULL);
	ctime_s(date, 26, &now);
	char name[61];
	printFrame();
	GotoXY(WALL_LEFT + 31, WALL_UP + 11);
	cout << "Ban muon luu voi ten: ";
	cin.getline(name, 61);
	FILE* f;
	fopen_s(&f, filePath, "a+");
	if (f == NULL)
		return;
	fputs(name, f);
	fprintf(f, "\n");
	fputs(date, f);
	fprintf(f, "%d\n", player.score);
	fprintf(f, "%d\n", player.speed);
	fprintf(f, "%d\n", SIZE_SNAKE);
	fprintf(f, "%d\n", FOOD_INDEX_REMAIN);
	fprintf(f, "%d\n", CHAR_LOCK);
	fprintf(f, "%d\n", direction);
	fprintf(f, "%d\n", levelUpCheck);
	fprintf(f, "%d\n", pauseCheck);
	fprintf(f, "%d\n", language);
	fprintf(f, "%d ", food.x);
	fprintf(f, "%d\n", food.y);
	for (int i = 0; i < SIZE_SNAKE; i++)
	{
		fprintf(f, "%d ", snake[i].x);
		fprintf(f, "%d\n", snake[i].y);
	}
	fclose(f);
	GotoXY(WALL_LEFT + 31, WALL_UP + 11);
	cout << "Luu thanh cong                     ";
	GotoXY(WALL_LEFT + 31, WALL_UP + 12);
	system("pause");
	system("cls");
	drawWall();
	if (pauseCheck == 1)
	{
		drawSnake();
		printGate();
		speedUpPoint();
		drawFood();
	}
}
void loadGame(const char filePath[])
{
	FILE* f;
	numofSave = 0;
	fopen_s(&f, filePath, "rt");
	if (f == NULL)
		return;
	char name[60];
	while (fgets(name, 60, f) != NULL)
	{
		save[numofSave].name = name;
		fgets(save[numofSave].date, 26, f);
		fscanf_s(f, "%d", &save[numofSave].score);
		fscanf_s(f, "%d", &save[numofSave].speed);
		fscanf_s(f, "%d", &save[numofSave].size);
		fscanf_s(f, "%d", &save[numofSave].foodRemain);
		fscanf_s(f, "%d", &save[numofSave].charLock);
		fscanf_s(f, "%d", &save[numofSave].direction);
		fscanf_s(f, "%d", &save[numofSave].levelCheck);
		fscanf_s(f, "%d", &save[numofSave].pauseCheck);
		fscanf_s(f, "%d", &save[numofSave].language);
		fscanf_s(f, "%d", &save[numofSave].food.x);
		fscanf_s(f, "%d", &save[numofSave].food.y);
		for (int i = 0; i < save[numofSave].size; i++)
		{
			fscanf_s(f, "%d", &save[numofSave].snake[i].x);
			fscanf_s(f, "%d", &save[numofSave].snake[i].y);
		}
		numofSave++;
		fgets(name, 60, f);
	}
	fseek(f, 1, SEEK_SET);
	fclose(f);
}
void printList()
{
	if (numofSave == 0)
	{
		GotoXY(40, 3);
		if (language == 1)
		{
			cout << "No records yet!!!\n";
		}
		else
		{
			cout << "Chua co ban luu nao!!!\n";
		}
		system("pause");
		return;
	}
	int row = 5;
	int check = 0;
	GotoXY(40, 3);
	if (language == 0)
	{
		cout << "Danh sach luu: ";
		for (int i = 0; i < numofSave; i++)
		{
			GotoXY(50, row); cout << "Ten: " << save[i].name;
			GotoXY(70, row); cout << "Cap do: " << save[i].speed;
			GotoXY(90, row); cout << "Diem: " << save[i].score;
			GotoXY(110, row); cout << "T/g luu: " << save[i].date;
			row += 2;
		}
		GotoXY(40, row);
		cout << "Nhan ENTER de chon, ESC de thoat";
	}
	else {
		cout << "Saved list: ";
		for (int i = 0; i < numofSave; i++)
		{
			GotoXY(50, row); cout << "Name: " << save[i].name;
			GotoXY(70, row); cout << "Levels: " << save[i].speed;
			GotoXY(90, row); cout << "Score: " << save[i].score;
			GotoXY(110, row); cout << "Time: " << save[i].date;
			row += 2;
		}
		GotoXY(40, row);
		cout << "Press ENTER to choose, ESC to escape";
	}
	row = 5;
	GotoXY(48, row);
	cout << (char)16;
	while (check == 0)
	{
		if (_kbhit())
		{
			char key = toupper(_getch());
			switch (key)
			{
			case 27: check = 1; break;
			case 'W':
			{
				if (row == 5)
				{
					break;
				}
				else
				{
					GotoXY(48, row);
					cout << " ";
					row -= 2;
					GotoXY(48, row);
					cout << (char)16;
					choiceSound();
					break;
				}
			}
			case 'S':
			{
				if (row == 5 + (numofSave - 1) * 2)
				{
					break;
				}
				else
				{
					GotoXY(48, row);
					cout << " ";
					row += 2;
					GotoXY(48, row);
					cout << (char)16;
					choiceSound();
					break;
				}
			}
			case 13:
			{
				STATE = 1;
				int idx = (row - 5) / 2;
				player.name = save[idx].name;
				CHAR_LOCK = save[idx].charLock;
				direction = save[idx].direction;
				food = save[idx].food;
				FOOD_INDEX_REMAIN = save[idx].foodRemain;
				language = save[idx].language;
				levelUpCheck = save[idx].levelCheck;
				pauseCheck = save[idx].pauseCheck;
				speedUpCheck = 0;
				player.score = save[idx].score;
				SIZE_SNAKE = save[idx].size;
				for (int i = 0; i < SIZE_SNAKE; i++)
				{
					snake[i].x = save[idx].snake[i].x;
					snake[i].y = save[idx].snake[i].y;
				}
				SPEED = save[idx].speed;
				system("cls");
				check = 1;
				system("cls");
				playSound();
				drawWall();
				ThreadFunc();
				break;
			}
			}
		}
	}
}